   <div class="clear">
        </div>
    </div>
    <div class="clear">
    </div>
    <div id="site_info">
        <p>
			CS307 CN Course Project by: 
			K163620 Abdul Mannan
			K163618 Murtaza Multanwala
        </p>
    </div>
</body>
</html>
