<!DOCTYPE html>
<html>
<head>
  <title>CatPalace</title>
</head>
<body>
<button><a href="user/user_login.php">User Login</a></button>
<button><a href="user/user_signup.php">User SignUp</a></button>
<button><a href="admin/admin_login.php">Admin LogIn</a></button>
</body>
</html>