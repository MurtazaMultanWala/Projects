<footer id="footer">

    <div class="footer-bottom">
        <div class="container">
            <div class="row">
                <p class="pull-left">CS307 CN Course Project by: 
            K163620 Abdul Mannan
            K163618 Murtaza Multanwala</p>
            </div>
        </div>
    </div>

</footer><!--/Footer-->



<script src="js/jquery.js"></script>
<script src="js/price-range.js"></script>
<script src="js/jquery.scrollUp.min.js"></script>
<script src="js/bootstrap.min.js"></script>
<script src="js/jquery.prettyPhoto.js"></script>
<script src="js/main.js"></script>
</body>
</html>