You need to install sql server for database connectivity

login id and pass will be shared soon.